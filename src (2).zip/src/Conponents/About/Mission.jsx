import './About.css'
// import { Link, NavLink } from "react-router-dom"


function Mission() {
  return (
    <div className='Mission-body'>
      <div className="flow">

      <div className="mission">
        <div className="logo" style={{textAlign: "center", fontSize: "30px", marginBottom: "40px"}}>
                        <b style={{fontFamily: "fantasy", letterSpacing: "2px", fontSize: "50px", paddingTop: "10px"}}>DU</b>FEED
                    </div>
      <h1>Mission</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, corporis? Esse deserunt, sint amet maiores sequi doloremque ex exercitationem,
         omnis laboriosam enim ratione iste a eaque velit molestias beatae culpa?
         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium quibusdam optio ab sit aliquid, autem voluptatum nulla doloremque facere ex!</p>
      </div>
      </div>

<div className="mid">

      <div className="load">
        <h2>Vision</h2>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias nemo voluptatibus modi inventore, obcaecati vero earum 
        repudiandae aut illum recusandae unde cupiditate natus repellendus expedita itaque.
         Accusantium repellendus unde quia, debitis nihil ipsam natus sit, ea quibusdam vol
         uptatum dignissimos corrupti!</p>
      </div>

      <div className="values">
        <h2>Our Core Values</h2>
        <ul>
          <li>Behavour stands</li>
          <li>Behavour standard</li>
          <li>Mission Growth</li>
          <li>Believers Love World</li>

        </ul>
      </div>
</div>
    </div>
  )
}

export default Mission