import './About.css'

function Carrier() {
  return (
    <div>
    <div className="carrier">

<div className="carr">
<h1>Our Carrier</h1>
<p>Lorem ipsum dolor sit amet consectetur
   adipisicing elit. Doloribus, corporis? 
   Esse deserunt, sint amet maiores sequi doloremque
    ex exercitationem, omnis laboriosam enim ratione iste a
     eaque velit molestias beatae culpa?
   lore30
   </p>
</div>

</div>
    </div>
  )
}

export default Carrier